list = []

list.append(67)
list.append(62.9)
list.append("hi")
list.append(False)
list += [8] 
list += [67] 
list += ["Apple"] 
list += [6.5]

print(list) 
