list = [8,9,10]

#Letter A
list[1] = 17
print(list)
#Letter B
list.extend([4, 5, 6])
print(list)
#Letter C
list.pop(0)
print(list)
#Letter D
list = sorted(list)
print(list)
#Letter E
list *= 2
print(list)
#Letter F
list.insert(3, 25)
print(list)
