def rectangle(m, n):
    for i in range (m):
        print('*'*n)
        
rectangle(2, 4)